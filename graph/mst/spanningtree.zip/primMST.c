/*
 * =====================================================================================
 *
 *       Filename:  primMST.c
 *
 *    Description:  Implementation for Prims's Algorithm to find a minimum spanning tree 
 *
 *        Version:  1.0
 *        Created:  04/13/2017 01:11:25 PM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Jared Bass & Lauren Sachs
 *         
 *         I pledge my honor that I have abided by the Stevens Honor System
 *
 * =====================================================================================
 */
#include <stdlib.h>
#include <math.h>
#include "primmst.h"
#include "minprio.h"

struct comp
{
    int index;
    float distance;    
};
typedef struct comp* Comp;

int compare(void* lhs, void* rhs)
{
    Comp c1 = (Comp) lhs;
    Comp c2 = (Comp) rhs;
    
    if(c1 -> distance < c2 -> distance)
    {
        return -1;
    }
    else
    {
        if(c1 -> distance == c2 -> distance)
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }
}

Graph minSpanTree(Graph g)
{
    int v = numVerts(g);
    Graph t = makeGraph(v, LIST);

    MinPrio q = makeQueue(compare, v);

    int link[v];

    for(int i = 0; i < v; i++)
    {
        link[i] = -1;
    }

    Handle hArray[v];

    Comp c = (Comp) malloc(sizeof(struct comp));
    c->index = 0;
    c->distance = 0;
    hArray[0] = enqueue(q, c);
    for(int i = 1; i < v; i++)
    {
        Comp ci = (Comp) malloc(sizeof(struct comp));
        ci -> index = i;
        ci -> distance = INFINITY;

        hArray[i] = enqueue(q, ci);
    }

    while(nonempty(q))
    {
        Comp min = (Comp) dequeueMin(q);
        hArray[min->index] = NULL;
        
        int* succ = successors(g, min->index);
        for(int i = 0; succ[i] != -1; i++)
        {
            if(hArray[succ[i]] != NULL)
            {
                Handle hi = hArray[succ[i]];
                Comp cData = (Comp) (hi -> content);
                if(edge(g,min->index, cData->index) < cData -> distance)
                {
                    link[succ[i]] = min -> index;
                    cData -> distance = edge(g, min->index, cData->index);
                    decreasedKey(q, hi);    
                }
            }
        }
    }

    for(int i = 0; i < v; i++)
    {
        addEdge(t, i, link[i], edge(g, i, link[i]));
        addEdge(t, link[i], i, edge(g, i, link[i]));
    }

    return t;
}
