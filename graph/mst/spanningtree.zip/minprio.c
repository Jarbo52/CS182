//Jared Bass and Lauren Sachs

#include <stdio.h>
#include <stdlib.h>
#include "minprio.h"

struct wrapper
{
    void* data;
    int index;
};
typedef struct wrapper* Wrapper;

struct minprio
{
    Comparator myComp;
    Handle* myHandles;
    Wrapper* q;
    int maxsize;
    int addloc;
};

MinPrio makeQueue(Comparator comp, int maxsize)
{
    maxsize++;
    MinPrio newMP = (MinPrio)malloc(sizeof(struct minprio));
    newMP -> myHandles = (Handle*)malloc(maxsize*sizeof(struct handle));
    newMP -> q = (Wrapper*)malloc(maxsize*sizeof(struct wrapper));
    newMP -> maxsize = maxsize;
    newMP-> addloc = 1;
    newMP->myComp = comp;

    return newMP;
}

void disposeQueue(MinPrio qp)
{
    Handle* handles = qp -> myHandles;
    Wrapper* queue = qp -> q;
    int ms = qp -> maxsize;

    for(int i = 0; i < ms; i++)
    {
        free(queue[i]);
        free(handles[i]);
        queue[i] = NULL;
        handles[i] = NULL;
    }

    free(queue);
    free(handles);
    free(qp);
    
    queue = NULL;
    handles = NULL;
    qp = NULL;
}

void swap(MinPrio qp, int w1, int w2)
{
    Wrapper temp = qp->q[w1];
    qp->myHandles[qp->q[w2]->index]->pos = w1;
    qp->myHandles[qp->q[w1]->index]->pos = w2;
    qp->q[w1] = qp->q[w2];
    qp->q[w2] = temp;

}

Handle enqueue(MinPrio qp, void* item)
{
    Comparator myComp = qp -> myComp;
  
    Handle newHandle = (Handle) malloc(sizeof(struct handle));
    newHandle->pos = qp->addloc;
    newHandle->content = item;
    qp->myHandles[qp->addloc] = newHandle;

    Wrapper w = (Wrapper) malloc(sizeof(struct wrapper));
    w->data = item;
    w->index = qp->addloc;
    qp->q[qp->addloc] = w;

    int trav = qp->addloc;

    while(trav > 1 && myComp(qp->q[trav/2]->data,item)>0)
    {
        swap(qp,trav/2,trav);

        trav = trav/2;
    }
    trav = 0;
    
    qp->addloc = qp->addloc + 1;
 
    return newHandle;
}

int nonempty(MinPrio qp)
{
    if(qp->addloc == 1)
        return 0;
    else
        return 1;
}

void* dequeueMin(MinPrio qp)
{
    void* toRem = qp->q[1]->data;

    Comparator comp = qp->myComp;
    
    int i = 1;

    int removeLocation = qp->q[1]->index;
    swap(qp, 1, qp->addloc-1);
    free(qp->myHandles[removeLocation]);
    qp->myHandles[removeLocation] = NULL;
    free(qp->q[qp->addloc-1]);
    qp->q[qp->addloc-1]=NULL;

    int trav = 1;
    qp->addloc = qp->addloc - 1;
    
    while(trav != 0 && trav < qp->addloc)
    {
        int doSwap = 1;

        int sideToUse = 0;
        int leftValid = (2*trav) < qp->addloc ? 1:0;
        int rightValid = (2*trav + 1) < qp->addloc ? 1:0;
        if(leftValid && rightValid)
        {
            int r = comp(qp->q[2*trav]->data, qp->q[2*trav+1]->data);
            if(r < 0)
                sideToUse = 2*trav;
            else
                sideToUse = 2*trav+1;   
        }
        else
        {
            if(leftValid)
            {
                sideToUse = 2*trav;
            }
            else
            {
                if(rightValid)
                {
                    sideToUse = 2*trav+1;
                }
                else
                {
                    trav = qp->addloc;
                    doSwap = 0;
                }

            }

        }
        int leftSwapNeeded = 0;
        int rightSwapNeeded = 0;
        if(leftValid)
        {
            if(comp(qp->q[trav]->data, qp->q[2*trav]->data) > 0)
            {
                leftSwapNeeded = 1;
            }
        }
        if(rightValid)
        {
            if(comp(qp->q[trav]->data, qp->q[2*trav+1]->data) > 0)
            {
                rightSwapNeeded = 1;
            }
        }

        if(leftSwapNeeded == 0 && rightSwapNeeded == 0)
        {
            trav = qp->addloc;
            doSwap = 0;
        }

        if(doSwap)
            swap(qp,trav, sideToUse);  
        
        trav = sideToUse;        
    }

    return toRem;
}

void decreasedKey(MinPrio qp, Handle hand)
{
    int pos = hand -> pos;
    Comparator comp = qp->myComp;

    int trav = pos;

    while(trav > 1 && comp(qp->q[trav/2]->data,qp->q[trav]->data)>0)
    {
        swap(qp,trav/2,trav);
        trav = trav/2;
    }
}





